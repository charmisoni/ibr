"""
Variable-by-Variable Explainer — AI-Driven Claims Verification in Indian Motor Insurance
------------------------------------------------------------------------------------------
Run locally:
    pip install -r requirements.txt
    streamlit run streamlit_app.py

Self-contained — no external data files needed.
"""

import streamlit as st
import plotly.graph_objects as go

# ====================================================================================
# PAGE CONFIG
# ====================================================================================
st.set_page_config(
    page_title="AI Claims Verification — Variable Explainer",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ====================================================================================
# DESIGN SYSTEM
# ====================================================================================
NAVY = "#1F2A44"
NAVY_SOFT = "#3A4562"
CORAL = "#E8735A"
CORAL_SOFT = "#F2A894"
CREAM = "#F5EFE6"
CREAM_DEEP = "#ECE2D0"
INK = "#222222"
MUTED = "#6B6B6B"
GREEN = "#3F7A5C"
GOLD = "#C9A227"
RED = "#A83E35"

VERDICT_COLOR = {
    "Converged & strong": GREEN,
    "Hidden gap": GOLD,
    "Confirmed null": RED,
    "Mixed": NAVY,
}
VERDICT_ICON = {
    "Converged & strong": "✓",
    "Hidden gap": "◐",
    "Confirmed null": "○",
    "Mixed": "◇",
}

st.markdown(
    f"""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700;800&family=Inter:wght@400;500;600;700&display=swap');

    html, body, [class*="css"]  {{
        font-family: 'Inter', -apple-system, sans-serif;
    }}
    .stApp {{
        background-color: {CREAM};
    }}
    h1, h2, h3 {{
        font-family: 'Playfair Display', Georgia, serif !important;
        color: {NAVY} !important;
    }}
    .hero {{
        background: linear-gradient(120deg, {NAVY} 0%, {NAVY_SOFT} 100%);
        padding: 36px 40px;
        border-radius: 14px;
        margin-bottom: 28px;
        box-shadow: 0 8px 24px rgba(31,42,68,0.25);
    }}
    .hero .kicker {{
        color: {CORAL_SOFT};
        text-transform: uppercase;
        letter-spacing: 0.14em;
        font-size: 11.5px;
        font-weight: 700;
        margin-bottom: 10px;
    }}
    .hero h1 {{
        color: #ffffff !important;
        font-size: 30px !important;
        margin: 0 0 10px 0 !important;
        line-height: 1.25;
    }}
    .hero p {{
        color: #d7dbe6;
        font-size: 14.5px;
        max-width: 780px;
        margin: 0;
    }}
    .kpi-strip {{
        display: flex;
        gap: 14px;
        margin-top: 22px;
        flex-wrap: wrap;
    }}
    .kpi-chip {{
        background: rgba(255,255,255,0.08);
        border: 1px solid rgba(255,255,255,0.18);
        border-radius: 10px;
        padding: 12px 18px;
        min-width: 130px;
    }}
    .kpi-chip .num {{
        color: {CORAL_SOFT};
        font-size: 22px;
        font-weight: 800;
        font-family: 'Playfair Display', serif;
    }}
    .kpi-chip .lab {{
        color: #c7cee3;
        font-size: 10.5px;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        margin-top: 2px;
    }}
    .badge {{
        display: inline-block;
        font-size: 11.5px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        padding: 6px 16px;
        border-radius: 20px;
        margin-bottom: 14px;
    }}
    .stat-card {{
        background: #ffffff;
        border-radius: 10px;
        padding: 16px 18px;
        border-left: 4px solid {NAVY};
        box-shadow: 0 2px 10px rgba(31,42,68,0.06);
        height: 100%;
    }}
    .stat-card.sig {{
        border-left: 4px solid {CORAL};
    }}
    .stat-card .v {{
        font-size: 21px;
        font-weight: 800;
        color: {NAVY};
        font-family: 'Playfair Display', serif;
    }}
    .stat-card.sig .v {{ color: {CORAL}; }}
    .stat-card .l {{
        font-size: 10.5px;
        color: {MUTED};
        text-transform: uppercase;
        letter-spacing: 0.03em;
        margin-top: 4px;
    }}
    .quote-card {{
        background: #ffffff;
        border-radius: 10px;
        padding: 16px 20px;
        margin-bottom: 12px;
        border-left: 4px solid {NAVY};
        box-shadow: 0 2px 10px rgba(31,42,68,0.06);
    }}
    .quote-card.gold {{ border-left-color: {GOLD}; }}
    .quote-card .src {{
        font-size: 10.5px;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        color: {CORAL};
        font-weight: 700;
        margin-bottom: 6px;
    }}
    .quote-card p {{
        font-style: italic;
        color: {NAVY_SOFT};
        font-size: 14px;
        margin: 0;
        line-height: 1.5;
    }}
    .meaning-box {{
        background: #ffffff;
        border-radius: 10px;
        padding: 20px 24px;
        box-shadow: 0 2px 10px rgba(31,42,68,0.06);
        font-size: 15px;
        line-height: 1.65;
        color: {INK};
        margin-bottom: 4px;
    }}
    section[data-testid="stSidebar"] {{
        background-color: {CREAM_DEEP};
    }}
    div[role="radiogroup"] label {{
        background: #ffffff;
        border-radius: 8px;
        padding: 8px 12px !important;
        margin-bottom: 4px;
        border: 1px solid {CREAM_DEEP};
    }}
    </style>
    """,
    unsafe_allow_html=True,
)

# ====================================================================================
# DATA
# ====================================================================================
VARIABLES = [
    {
        "code": "RA", "name": "Relative Advantage", "verdict": "Converged & strong",
        "stats": {"β → Decision Speed": ("0.716", True), "β → Fraud Detection": ("0.476", True),
                   "f² (Decision Speed)": ("0.81 — large", False), "Reliability (α)": ("0.861", False)},
        "meaning": ("People's belief that AI genuinely works better than the old manual way is the "
                    "single biggest reason it gets adopted and used well. Both survey questions for "
                    "this topic agreed with each other closely, so the measurement is clean, and this "
                    "is your strongest and most trustworthy finding."),
        "interview": ("\"AI has flagged the possible fraudulent claims basis our past experiences for "
                       "which prompts or scenarios were given to the system.\" — R1 (zonal claims manager)"),
        "opentext": ["\"AI can be a game changer in claim management.\" (said identically by 5 different respondents)",
                     "\"Auto Process and less manual process so reduce time and work more efficient.\""],
    },
    {
        "code": "FDC", "name": "Fraud Detection Capacity (mediator)", "verdict": "Converged & strong",
        "stats": {"β → Operational Efficiency": ("0.426", True), "R²": ("0.653", False),
                   "Reliability (α)": ("0.913", False), "Outer loadings": ("0.963 / 0.956", False)},
        "meaning": ("Of everything AI does, catching fraud is where it earns its keep most clearly and "
                    "measurably — and this is one of the best-measured parts of your whole survey."),
        "interview": ("\"...they are using AI primarily for fraud and leakage detection, and that's where "
                       "the ROI of AI is highest anyway.\" — R2"),
        "opentext": ["\"Fraud detection\" (a respondent's entire answer)",
                     "\"Claim inspection records and past lost history can help to identify duplicate / old claim before it get processed.\""],
    },
    {
        "code": "DMS", "name": "Decision-Making Speed (mediator)", "verdict": "Converged & strong",
        "stats": {"β → Operational Efficiency": ("0.410", True), "R²": ("0.636", False),
                   "Reliability (α)": ("0.786", False), "Outer loadings": ("0.911 / 0.904", False)},
        "meaning": ("Speed gains are real and are one of the two main routes (along with fraud "
                    "detection) through which AI actually improves the business."),
        "interview": ("Implied throughout rather than named directly — R1's verification wins and R2's "
                       "\"real-time photo-based inspection, real-time estimates\" both describe speed gains."),
        "opentext": ["\"Auto Process and less manual process so reduce time and work more efficient.\"",
                     "\"Due to AI more help settle claim.\""],
    },
    {
        "code": "CDA", "name": "Customer Digital Adoption", "verdict": "Mixed",
        "stats": {"β → Decision Speed": ("0.174 (ns)", False), "β → Fraud Detection": ("0.354", True),
                   "f² (Fraud Detection)": ("0.233", False), "Reliability (α)": ("0.493", False)},
        "meaning": ("Split result: customer readiness feeds directly into fraud detection (digital "
                    "photos and submissions become raw material for the system) but doesn't "
                    "significantly affect internal decision speed, which is more about the company's "
                    "own workflow than what the customer does."),
        "interview": ("\"IOT has picked up extremely well in India... it has deeply penetrated even in "
                       "the rural belts.\" — R1"),
        "opentext": ["No direct match on digital-skill readiness in the open text.",
                     "A related but different concern appears instead: \"Machine has no empathy. In death and injury claims the customer needs a person to talk to, not a bot.\""],
    },
    {
        "code": "DQA", "name": "Data Quality & Accuracy", "verdict": "Hidden gap",
        "stats": {"β → Decision Speed": ("0.080 (ns)", False), "β → Fraud Detection": ("0.216 (p=.079)", False),
                   "SmartPLS-reported α": ("0.443", False), "Recomputed α": ("0.767", True)},
        "meaning": ("Officially \"no effect\" — but the two survey questions for this topic didn't "
                    "agree well with each other, which weakens any conclusion. Likely the measuring "
                    "tool wasn't sharp enough here, not that data quality genuinely doesn't matter."),
        "interview": ("\"...it has to be a correct and efficient collection of the data about all claims "
                       "since AI will need accurate data.\" — R1's one piece of closing advice"),
        "opentext": ["\"Less hallucinations and more learning backed by data which is scattered now at multiple sources.\"",
                     "\"If the claims processed data of leading companies is merged to train AI it can get more effective.\"",
                     "\"Structured machine readable information.\""],
    },
    {
        "code": "SIC", "name": "System Integration Compatibility", "verdict": "Hidden gap",
        "stats": {"β → Decision Speed": ("0.069 (ns)", False), "β → Fraud Detection": ("-0.005 (ns)", False),
                   "Reliability (α)": ("0.581", False), "Open-text mentions": ("12 of 105", False)},
        "meaning": ("No significant effect — most people already rated their systems as \"good "
                    "enough, not great,\" so there wasn't much variation left to explain other outcomes."),
        "interview": ("Neither expert discussed this directly, though R1's fraud-catching examples "
                       "quietly depend on systems being connected to government databases."),
        "opentext": ["\"Integrate AI with policy and claims systems, improve document verification and fraud detection.\"",
                     "\"Our legacy portal does not support any API integration, so AI tool has to work separately which defeats the purpose.\" (said by 3 different respondents)"],
    },
    {
        "code": "EC", "name": "Employee Competence", "verdict": "Hidden gap",
        "stats": {"β → Decision Speed": ("-0.006 (ns)", False), "β → Fraud Detection": ("0.002 (ns)", False),
                   "SmartPLS-reported α": ("0.367", False), "Recomputed α": ("0.778", True)},
        "meaning": ("The flattest result in the whole study — but when raw answers were recoded with "
                    "consistent polarity, this topic looked reliable. Very likely a data-entry/coding "
                    "issue, not a true absence of effect. Also the #1 most-mentioned theme in the "
                    "open-text data (13 of 105, unprompted)."),
        "interview": ("\"We have seen people taking this change as complete non sense... after some time "
                       "when some cases highlighted by system helped them... they start adopting and "
                       "accepting these things.\" — trust builds gradually, which one survey question can't capture."),
        "opentext": ["\"Need professional training on AI tools and adaption of AI technology.\"",
                     "\"Proper training is required for claim handlers, otherwise they will not trust the output and will do manual check anyway.\""],
    },
    {
        "code": "TMS", "name": "Top Management Support", "verdict": "Hidden gap",
        "stats": {"β → Decision Speed": ("0.045 (ns)", False), "β → Fraud Detection": ("0.004 (ns)", False),
                   "SmartPLS-reported α": ("0.395", False), "Recomputed α": ("0.738", True)},
        "meaning": "No significant effect — same likely measurement-issue story as Employee Competence.",
        "interview": ("Neither expert addressed this directly, though R2's ROI-skepticism (\"you're not "
                       "subtracting cost, you're adding it\") is itself a management-level hesitation."),
        "opentext": ["Fewer voices (6 of 105) but sharp: \"Top management support is there on paper but budget is not sanctioned.\" (said by 2 respondents)",
                     "\"Top leadership investment.\""],
    },
    {
        "code": "SCP", "name": "Regulatory Clarity", "verdict": "Confirmed null",
        "stats": {"β → Decision Speed": ("-0.085 (ns)", False), "β → Fraud Detection": ("-0.218 (ns)", False),
                   "SCP1 outer loading": ("-0.670", False), "Open-text mentions": ("0 of 105", False)},
        "meaning": ("Not a measurement mistake — one item (\"rules are clear\") and the other (\"we're "
                    "closely monitored\") genuinely point in different directions, which makes real-world "
                    "sense: regulators often watch more closely exactly when things aren't settled yet. "
                    "Every source agrees this genuinely isn't the problem."),
        "interview": ("\"I don't know how IRDAI can impose use of AI on the insurers... it is up to the "
                       "insurance companies.\" — R1, dismissing it outright"),
        "opentext": ["Zero. Not one of 105 respondents mentioned regulation as something that needs to change."],
    },
    {
        "code": "OE", "name": "Operational Efficiency (outcome)", "verdict": "Mixed",
        "stats": {"R²": ("0.627", True), "DV3 outer loading": ("0.968", False),
                   "DV1 / DV2 / DV4 loadings": ("0.32 – 0.40", False), "AVE": ("0.331", False)},
        "meaning": ("Well explained overall — but the four questions measuring \"efficiency\" secretly "
                    "split into two ideas: a Speed pair that agree closely with each other (r=.88), and "
                    "a Resource-Use pair that barely relate to the speed pair (r=.04–.20). People answer "
                    "these as two separate mental questions, not one."),
        "interview": ("R2's framing fits exactly: efficiency gains are concentrated in a specific slice "
                       "of claims (small, simple, digitally comfortable, no third party) rather than "
                       "applying evenly everywhere."),
        "opentext": ["Efficiency comments are scattered across many quotes already shown above (speed, auto-processing, resource use) rather than forming one distinct cluster — consistent with \"efficiency\" not being one single idea."],
    },
]
MAX_BETA = [0.716, 0.426, 0.410, 0.354, 0.216, 0.069, 0.006, 0.045, 0.218, 0.968]

# ====================================================================================
# HERO
# ====================================================================================
n_strong = sum(1 for v in VARIABLES if v["verdict"] == "Converged & strong")
n_hidden = sum(1 for v in VARIABLES if v["verdict"] == "Hidden gap")

st.markdown(
    f"""
    <div class="hero">
        <div class="kicker">Variable-by-Variable Explainer</div>
        <h1>What each PLS-SEM result means, and what people actually said about it</h1>
        <p>AI-Driven Claims Verification in Indian Motor Insurance — every construct's quantitative
        result, plain-language meaning, and real supporting quotes from two expert interviews and
        94 open-text survey answers, side by side.</p>
        <div class="kpi-strip">
            <div class="kpi-chip"><div class="num">105</div><div class="lab">Respondents</div></div>
            <div class="kpi-chip"><div class="num">10</div><div class="lab">Constructs explained</div></div>
            <div class="kpi-chip"><div class="num">{n_strong}</div><div class="lab">Converged &amp; strong</div></div>
            <div class="kpi-chip"><div class="num">{n_hidden}</div><div class="lab">Hidden gaps</div></div>
            <div class="kpi-chip"><div class="num">94</div><div class="lab">Open-text answers read</div></div>
        </div>
    </div>
    """,
    unsafe_allow_html=True,
)

# ====================================================================================
# SIDEBAR
# ====================================================================================
st.sidebar.markdown("### 📊 Choose a variable")
labels = [f"{VERDICT_ICON[v['verdict']]}  {v['code']} — {v['name']}" for v in VARIABLES]
choice = st.sidebar.radio(" ", labels, index=0, label_visibility="collapsed")
selected = VARIABLES[labels.index(choice)]

st.sidebar.markdown("---")
st.sidebar.markdown("#### Legend")
for verdict, color in VERDICT_COLOR.items():
    st.sidebar.markdown(
        f"<div style='display:flex; align-items:center; gap:8px; margin-bottom:6px;'>"
        f"<span style='width:12px; height:12px; border-radius:3px; background:{color}; display:inline-block;'></span>"
        f"<span style='font-size:13px; color:{INK};'>{verdict}</span></div>",
        unsafe_allow_html=True,
    )

st.sidebar.markdown("---")
st.sidebar.caption(
    "Built from SmartPLS 4 output, 2 expert interviews, and 94 open-text survey answers. "
    "All data embedded — no external files needed."
)

# ====================================================================================
# MAIN — selected variable
# ====================================================================================
col_main, col_side = st.columns([1.5, 1])

with col_main:
    badge_color = VERDICT_COLOR[selected["verdict"]]
    st.markdown(
        f"<span class='badge' style='background:{badge_color}22; color:{badge_color};'>"
        f"{VERDICT_ICON[selected['verdict']]}  {selected['verdict']}</span>",
        unsafe_allow_html=True,
    )
    st.markdown(f"## {selected['name']}")

    stat_cols = st.columns(len(selected["stats"]))
    for c, (label, (value, sig)) in zip(stat_cols, selected["stats"].items()):
        with c:
            st.markdown(
                f"<div class='stat-card {'sig' if sig else ''}'>"
                f"<div class='v'>{value}</div><div class='l'>{label}</div></div>",
                unsafe_allow_html=True,
            )

    st.markdown("<br>", unsafe_allow_html=True)
    st.markdown("##### What this means")
    st.markdown(f"<div class='meaning-box'>{selected['meaning']}</div>", unsafe_allow_html=True)

with col_side:
    st.markdown("##### Where every variable sits")
    fig = go.Figure(
        go.Bar(
            x=MAX_BETA,
            y=[v["code"] for v in VARIABLES],
            orientation="h",
            marker_color=[VERDICT_COLOR[v["verdict"]] for v in VARIABLES],
            marker_line_width=0,
            hovertemplate="%{y}: max |β| = %{x}<extra></extra>",
        )
    )
    fig.update_layout(
        height=400,
        margin=dict(l=10, r=10, t=10, b=10),
        xaxis_title="Max |β| on any path",
        plot_bgcolor="white",
        paper_bgcolor="rgba(0,0,0,0)",
        font=dict(family="Inter, sans-serif", size=12, color=INK),
        xaxis=dict(gridcolor="#eee2d0"),
        yaxis=dict(autorange="reversed"),
    )
    st.plotly_chart(fig, use_container_width=True)

st.markdown("<br>", unsafe_allow_html=True)
qcol1, qcol2 = st.columns(2)

with qcol1:
    st.markdown("##### 🎙️ What the interview says")
    st.markdown(
        f"<div class='quote-card'><div class='src'>Expert interview</div>"
        f"<p>{selected['interview']}</p></div>",
        unsafe_allow_html=True,
    )

with qcol2:
    st.markdown("##### 📝 What the survey's open-text answers say")
    for q in selected["opentext"]:
        st.markdown(
            f"<div class='quote-card gold'><p>{q}</p></div>",
            unsafe_allow_html=True,
        )

st.markdown("---")
st.caption(
    "Data pack: IBR_Analysis_Data_Pack.xlsx · Interviews: Document6 (R1), interview_2 (R2) · "
    "Open-text: 94 of 105 respondents answered the free-text survey question."
)
